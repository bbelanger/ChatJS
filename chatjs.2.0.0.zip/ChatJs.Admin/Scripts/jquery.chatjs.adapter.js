﻿//# sourceMappingURL=jquery.chatjs.adapter.js.map
