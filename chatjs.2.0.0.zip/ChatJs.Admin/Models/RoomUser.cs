﻿namespace ChatJs.Admin.Models
{
    public class RoomUserViewModel
    {
        public int UserId { get; set; }
        public string UserDisplayName { get; set; }
        public bool IsEnlisted { get; set; }
    }
}