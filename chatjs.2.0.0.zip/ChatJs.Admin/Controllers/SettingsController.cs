﻿using System.Web.Mvc;

namespace ChatJs.Admin.Controllers
{
    [Authorize]
    public class SettingsController
    {
    }
}