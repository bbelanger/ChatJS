using System.Data.Entity.Migrations;

namespace ChatJs.Model.Migrations
{
    public partial class test : DbMigration
    {
        public override void Up()
        {
        }

        public override void Down()
        {
        }
    }
}